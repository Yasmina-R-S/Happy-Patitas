import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> guardarCollar({
    required String idDueno,
    required String idMascota,
    required int bateria,
  }) async {
    try {
      await _db.collection('collares').add({
        'idDueno': idDueno,
        'idMascota': idMascota,
        'bateria': bateria,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      rethrow;
    }
  }
}
