// lib/screens/ai_chat_screen.dart
// ─────────────────────────────────────────────────────────────────────────────
//  Happy Patitas · AI Chat Screen  –  Premium Dark UI
//  Requiere en pubspec.yaml:
//    google_fonts: ^6.x
//    flutter_animate: ^4.x  (o usa AnimationController nativo – incluido abajo
//                            con AnimatedOpacity/SlideTransition para 0 deps extra)
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../models/chat_message.dart';
import '../services/ai_service.dart';

// ─── Paleta de color ────────────────────────────────────────────────────────

class _Palette {
  static const bg          = Color(0xFF0D0F14);
  static const surface     = Color(0xFF161B25);
  static const surfaceHigh = Color(0xFF1E2533);
  static const border      = Color(0xFF252D3D);
  static const accent      = Color(0xFF6C8EFF);   // azul lavanda
  static const accentGlow  = Color(0x336C8EFF);
  static const accentDark  = Color(0xFF3D5AE8);
  static const userBubble  = Color(0xFF2A3A7C);
  static const aiBubble    = Color(0xFF1A2035);
  static const textPrimary = Color(0xFFF0F2FF);
  static const textSub     = Color(0xFF8A93B4);
  static const typing      = Color(0xFF6C8EFF);
  static const send        = Color(0xFF6C8EFF);
  static const paw         = Color(0xFFFF9F6B);   // naranja cálido para mascota
}

// ─── Modelo de mensaje extendido ────────────────────────────────────────────

class _ChatEntry {
  final ChatMessage message;
  final DateTime timestamp;
  final String id;

  _ChatEntry({required this.message, required this.timestamp})
      : id = '${timestamp.millisecondsSinceEpoch}_${math.Random().nextInt(9999)}';
}

// ─── Screen principal ────────────────────────────────────────────────────────

class AIChatScreen extends StatefulWidget {
  const AIChatScreen({super.key});

  @override
  State<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends State<AIChatScreen>
    with TickerProviderStateMixin {
  final TextEditingController _inputController = TextEditingController();
  final ScrollController      _scrollController = ScrollController();
  final FocusNode             _focusNode = FocusNode();

  final List<_ChatEntry> _entries = [];
  bool _isTyping   = false;
  bool _hasText    = false;
  bool _isFocused  = false;

  // Animación del botón send
  late final AnimationController _sendPulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  // Animación del header shimmer
  late final AnimationController _shimmer = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..repeat();

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_onTextChanged);
    _focusNode.addListener(_onFocusChanged);
    // Mensaje de bienvenida
    Future.delayed(const Duration(milliseconds: 600), _sendWelcome);
  }

  void _onTextChanged() {
    final has = _inputController.text.trim().isNotEmpty;
    if (has != _hasText) setState(() => _hasText = has);
  }

  void _onFocusChanged() {
    setState(() => _isFocused = _focusNode.hasFocus);
  }

  void _sendWelcome() {
    _addAIMessage(
      '¡Hola! 🐾 Soy tu asistente veterinario IA. '
      'Puedo ayudarte con consejos sobre la salud, alimentación y '
      'bienestar de tu mascota. ¿En qué puedo ayudarte hoy?',
    );
  }

  void _addAIMessage(String text) {
    setState(() {
      _entries.add(_ChatEntry(
        message: ChatMessage(text: text, isUser: false),
        timestamp: DateTime.now(),
      ));
    });
    _scrollToBottom();
  }

  Future<void> _sendMessage() async {
    final text = _inputController.text.trim();
    if (text.isEmpty || _isTyping) return;

    HapticFeedback.lightImpact();

    setState(() {
      _entries.add(_ChatEntry(
        message: ChatMessage(text: text, isUser: true),
        timestamp: DateTime.now(),
      ));
      _isTyping = true;
    });

    _inputController.clear();
    _scrollToBottom();

    try {
      final reply = await AIService.sendMessage(text);
      if (!mounted) return;
      setState(() {
        _isTyping = false;
        _entries.add(_ChatEntry(
          message: ChatMessage(text: reply, isUser: false),
          timestamp: DateTime.now(),
        ));
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isTyping = false;
        _entries.add(_ChatEntry(
          message: ChatMessage(
            text: 'Ups, ocurrió un error al conectar con la IA. '
                  'Por favor, inténtalo de nuevo. 🙏',
            isUser: false,
          ),
          timestamp: DateTime.now(),
        ));
      });
    }

    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent + 120,
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    _sendPulse.dispose();
    _shimmer.dispose();
    super.dispose();
  }

  // ──────────────────────────────────────────────────────────────────────────
  //  BUILD
  // ──────────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _Palette.bg,
        body: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(child: _buildMessageList()),
              if (_isTyping) _buildTypingIndicator(),
              _buildInputBar(),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _Palette.surface,
        border: Border(
          bottom: BorderSide(color: _Palette.border, width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Botón atrás
          _HeaderButton(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.of(context).pop(),
          ),
          const SizedBox(width: 12),

          // Avatar IA con glow animado
          _AIAvatar(shimmer: _shimmer),
          const SizedBox(width: 12),

          // Título + estado
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Asistente Veterinario',
                  style: GoogleFonts.plusJakartaSans(
                    color: _Palette.textPrimary,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.1,
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _shimmer,
                      builder: (_, __) => Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isTyping
                              ? _Palette.paw
                              : const Color(0xFF4ADE80),
                          boxShadow: [
                            BoxShadow(
                              color: (_isTyping
                                      ? _Palette.paw
                                      : const Color(0xFF4ADE80))
                                  .withOpacity(
                                      0.5 + 0.4 * _shimmer.value),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      _isTyping ? 'Escribiendo...' : 'En línea',
                      style: GoogleFonts.plusJakartaSans(
                        color: _Palette.textSub,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Menú / info
          _HeaderButton(
            icon: Icons.more_vert_rounded,
            onTap: () => _showInfoSheet(context),
          ),
        ],
      ),
    );
  }

  // ── Lista de mensajes ─────────────────────────────────────────────────────

  Widget _buildMessageList() {
    if (_entries.isEmpty) {
      return _buildEmptyState();
    }

    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      itemCount: _entries.length,
      itemBuilder: (context, index) {
        final entry = _entries[index];
        final isFirst = index == 0;
        final showDate = isFirst ||
            _entries[index].timestamp.day !=
                _entries[index - 1].timestamp.day;

        return Column(
          children: [
            if (showDate) _buildDateDivider(entry.timestamp),
            _AnimatedMessageBubble(
              key: ValueKey(entry.id),
              entry: entry,
              isLast: index == _entries.length - 1,
            ),
          ],
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _Palette.accentGlow,
              border: Border.all(color: _Palette.accent.withOpacity(0.3), width: 1.5),
            ),
            child: const Icon(Icons.pets_rounded, color: _Palette.paw, size: 36),
          ),
          const SizedBox(height: 16),
          Text(
            'Pregunta lo que quieras',
            style: GoogleFonts.plusJakartaSans(
              color: _Palette.textSub,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateDivider(DateTime dt) {
    final label = _formatDate(dt);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(child: Divider(color: _Palette.border, thickness: 1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                color: _Palette.textSub,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(child: Divider(color: _Palette.border, thickness: 1)),
        ],
      ),
    );
  }

  // ── Indicador "escribiendo…" ──────────────────────────────────────────────

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.only(left: 14, bottom: 4, top: 2),
      child: Row(
        children: [
          _SmallAIAvatar(),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _Palette.aiBubble,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(18),
                bottomLeft: Radius.circular(18),
                bottomRight: Radius.circular(18),
              ),
              border: Border.all(color: _Palette.border, width: 1),
            ),
            child: _TypingDots(),
          ),
        ],
      ),
    );
  }

  // ── Input bar ─────────────────────────────────────────────────────────────

  Widget _buildInputBar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _Palette.surface,
        border: Border(
          top: BorderSide(
            color: _isFocused ? _Palette.accent.withOpacity(0.4) : _Palette.border,
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
          if (_isFocused)
            BoxShadow(
              color: _Palette.accent.withOpacity(0.08),
              blurRadius: 30,
              offset: const Offset(0, -8),
            ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Campo de texto
          Expanded(
            child: Container(
              constraints: const BoxConstraints(maxHeight: 140),
              decoration: BoxDecoration(
                color: _Palette.surfaceHigh,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: _isFocused
                      ? _Palette.accent.withOpacity(0.5)
                      : _Palette.border,
                  width: 1.5,
                ),
              ),
              child: TextField(
                controller: _inputController,
                focusNode: _focusNode,
                maxLines: null,
                minLines: 1,
                keyboardType: TextInputType.multiline,
                textInputAction: TextInputAction.newline,
                style: GoogleFonts.plusJakartaSans(
                  color: _Palette.textPrimary,
                  fontSize: 14.5,
                  height: 1.45,
                ),
                cursorColor: _Palette.accent,
                decoration: InputDecoration(
                  hintText: '¿Cómo está tu mascota hoy?',
                  hintStyle: GoogleFonts.plusJakartaSans(
                    color: _Palette.textSub,
                    fontSize: 14.5,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 12,
                  ),
                  // Ícono de pata
                  prefixIcon: const Padding(
                    padding: EdgeInsets.only(left: 12, right: 4),
                    child: Icon(Icons.pets_rounded,
                        color: _Palette.paw, size: 18),
                  ),
                  prefixIconConstraints: const BoxConstraints(
                    minWidth: 40,
                    minHeight: 0,
                  ),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // Botón Send
          _SendButton(
            hasText: _hasText,
            isTyping: _isTyping,
            pulse: _sendPulse,
            onTap: _sendMessage,
          ),
        ],
      ),
    );
  }

  // ── Sheet info ────────────────────────────────────────────────────────────

  void _showInfoSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _Palette.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _Palette.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Icon(Icons.pets_rounded, color: _Palette.paw, size: 40),
            const SizedBox(height: 12),
            Text(
              'Asistente Veterinario IA',
              style: GoogleFonts.plusJakartaSans(
                color: _Palette.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Powered by OpenRouter · LLaMA 3',
              style: GoogleFonts.plusJakartaSans(
                color: _Palette.textSub,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Este asistente ofrece orientación general sobre mascotas. '
              'Para diagnósticos médicos, consulta siempre a un veterinario.',
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                color: _Palette.textSub,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                style: TextButton.styleFrom(
                  backgroundColor: _Palette.accentGlow,
                  foregroundColor: _Palette.accent,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  'Cerrar',
                  style: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    if (dt.year == now.year && dt.month == now.month && dt.day == now.day) {
      return 'Hoy';
    }
    final yesterday = now.subtract(const Duration(days: 1));
    if (dt.year == yesterday.year &&
        dt.month == yesterday.month &&
        dt.day == yesterday.day) return 'Ayer';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SUB-WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

// ── Burbuja de mensaje animada ────────────────────────────────────────────────

class _AnimatedMessageBubble extends StatefulWidget {
  final _ChatEntry entry;
  final bool isLast;

  const _AnimatedMessageBubble({
    super.key,
    required this.entry,
    required this.isLast,
  });

  @override
  State<_AnimatedMessageBubble> createState() => _AnimatedMessageBubbleState();
}

class _AnimatedMessageBubbleState extends State<_AnimatedMessageBubble>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  );

  late final Animation<double>   _opacity = CurvedAnimation(
    parent: _ctrl, curve: Curves.easeOut,
  );
  late final Animation<Offset>   _slide = Tween<Offset>(
    begin: Offset(widget.entry.message.isUser ? 0.18 : -0.18, 0.06),
    end: Offset.zero,
  ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));

  @override
  void initState() {
    super.initState();
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isUser = widget.entry.message.isUser;

    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(
        position: _slide,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(
            mainAxisAlignment:
                isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!isUser) ...[
                _SmallAIAvatar(),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Column(
                  crossAxisAlignment: isUser
                      ? CrossAxisAlignment.end
                      : CrossAxisAlignment.start,
                  children: [
                    _Bubble(entry: widget.entry),
                    const SizedBox(height: 3),
                    _Timestamp(dt: widget.entry.timestamp, isUser: isUser),
                  ],
                ),
              ),
              if (isUser) ...[
                const SizedBox(width: 8),
                _UserAvatar(),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ── Burbuja ────────────────────────────────────────────────────────────────

class _Bubble extends StatelessWidget {
  final _ChatEntry entry;
  const _Bubble({required this.entry});

  @override
  Widget build(BuildContext context) {
    final isUser = entry.message.isUser;

    final borderRadius = isUser
        ? const BorderRadius.only(
            topLeft: Radius.circular(18),
            topRight: Radius.circular(4),
            bottomLeft: Radius.circular(18),
            bottomRight: Radius.circular(18),
          )
        : const BorderRadius.only(
            topLeft: Radius.circular(4),
            topRight: Radius.circular(18),
            bottomLeft: Radius.circular(18),
            bottomRight: Radius.circular(18),
          );

    return GestureDetector(
      onLongPress: () {
        Clipboard.setData(ClipboardData(text: entry.message.text));
        HapticFeedback.mediumImpact();
      },
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.72,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
        decoration: BoxDecoration(
          color: isUser ? _Palette.userBubble : _Palette.aiBubble,
          borderRadius: borderRadius,
          border: Border.all(
            color: isUser
                ? _Palette.accent.withOpacity(0.25)
                : _Palette.border,
            width: 1,
          ),
          gradient: isUser
              ? const LinearGradient(
                  colors: [Color(0xFF2E4299), Color(0xFF1E2F70)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
            if (isUser)
              BoxShadow(
                color: _Palette.accent.withOpacity(0.12),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
          ],
        ),
        child: SelectableText(
          entry.message.text,
          style: GoogleFonts.plusJakartaSans(
            color: _Palette.textPrimary,
            fontSize: 14.5,
            height: 1.5,
            fontWeight: FontWeight.w400,
          ),
        ),
      ),
    );
  }
}

// ── Timestamp ─────────────────────────────────────────────────────────────

class _Timestamp extends StatelessWidget {
  final DateTime dt;
  final bool isUser;

  const _Timestamp({required this.dt, required this.isUser});

  @override
  Widget build(BuildContext context) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '$h:$m',
          style: GoogleFonts.plusJakartaSans(
            color: _Palette.textSub,
            fontSize: 10.5,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (isUser) ...[
          const SizedBox(width: 4),
          const Icon(Icons.done_all_rounded,
              color: _Palette.accent, size: 13),
        ],
      ],
    );
  }
}

// ── Avatar IA grande (header) ─────────────────────────────────────────────

class _AIAvatar extends StatelessWidget {
  final AnimationController shimmer;
  const _AIAvatar({required this.shimmer});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: shimmer,
      builder: (_, __) {
        return Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFF4F6FE8), Color(0xFF8A6FFF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: _Palette.accent
                    .withOpacity(0.25 + 0.2 * shimmer.value),
                blurRadius: 16,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Icon(Icons.pets_rounded, color: Colors.white, size: 22),
        );
      },
    );
  }
}

// ── Avatar IA pequeño (burbujas) ──────────────────────────────────────────

class _SmallAIAvatar extends StatelessWidget {
  const _SmallAIAvatar();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 30,
      height: 30,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [Color(0xFF4F6FE8), Color(0xFF8A6FFF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child:
          const Icon(Icons.pets_rounded, color: Colors.white, size: 15),
    );
  }
}

// ── Avatar usuario ────────────────────────────────────────────────────────

class _UserAvatar extends StatelessWidget {
  const _UserAvatar();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _Palette.surfaceHigh,
        border: Border.all(color: _Palette.border, width: 1.5),
      ),
      child: const Icon(Icons.person_rounded,
          color: _Palette.textSub, size: 17),
    );
  }
}

// ── Puntos "escribiendo…" ─────────────────────────────────────────────────

class _TypingDots extends StatefulWidget {
  const _TypingDots();

  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1100),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 46,
      height: 16,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(3, (i) {
          return AnimatedBuilder(
            animation: _ctrl,
            builder: (_, __) {
              final t = (_ctrl.value - i * 0.18).clamp(0.0, 1.0);
              final scale = 0.7 + 0.6 * math.sin(t * math.pi);
              return Transform.scale(
                scale: scale,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _Palette.typing.withOpacity(
                        0.5 + 0.5 * math.sin(t * math.pi)),
                  ),
                ),
              );
            },
          );
        }),
      ),
    );
  }
}

// ── Botón Send ────────────────────────────────────────────────────────────

class _SendButton extends StatelessWidget {
  final bool hasText;
  final bool isTyping;
  final AnimationController pulse;
  final VoidCallback onTap;

  const _SendButton({
    required this.hasText,
    required this.isTyping,
    required this.pulse,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = hasText && !isTyping;

    return AnimatedBuilder(
      animation: pulse,
      builder: (_, __) {
        final glowOpacity = active ? (0.3 + 0.2 * pulse.value) : 0.0;

        return GestureDetector(
          onTap: active ? onTap : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: active
                  ? const LinearGradient(
                      colors: [Color(0xFF6C8EFF), Color(0xFF4F5EE0)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              color: active ? null : _Palette.surfaceHigh,
              boxShadow: [
                BoxShadow(
                  color: _Palette.accent.withOpacity(glowOpacity),
                  blurRadius: 16,
                  spreadRadius: 2,
                ),
              ],
              border: Border.all(
                color: active
                    ? _Palette.accent.withOpacity(0.5)
                    : _Palette.border,
                width: 1.5,
              ),
            ),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: isTyping
                  ? const SizedBox(
                      key: ValueKey('loading'),
                      width: 20,
                      height: 20,
                      child: Padding(
                        padding: EdgeInsets.all(13),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _Palette.accent,
                        ),
                      ),
                    )
                  : Icon(
                      key: const ValueKey('send'),
                      Icons.send_rounded,
                      color: active
                          ? Colors.white
                          : _Palette.textSub,
                      size: 20,
                    ),
            ),
          ),
        );
      },
    );
  }
}

// ── Botón header genérico ─────────────────────────────────────────────────

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _HeaderButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        splashColor: _Palette.accent.withOpacity(0.1),
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: _Palette.surfaceHigh,
            border: Border.all(color: _Palette.border, width: 1),
          ),
          child: Icon(icon, color: _Palette.textSub, size: 18),
        ),
      ),
    );
  }
}
