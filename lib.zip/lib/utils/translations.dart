
import 'package:flutter/material.dart';

class T {
  static final Map<String, Map<String, String>> _v = {
    'es': {
      'settings': 'Configuración',
      'notifications': 'Notificaciones',
      'privacy': 'Privacidad y seguridad',
      'dark_mode': 'Modo oscuro',
      'language': 'Idioma',
      'device_settings': 'AJUSTES DEL DISPOSITIVO',
      'app_settings': 'AJUSTES DE LA APP',
      'battery_alerts': 'Alertas de batería',
      'collar_management': 'Gestión del collar',
      'support': 'Soporte',
    },
    'en': {
      'settings': 'Settings',
      'notifications': 'Notifications',
      'privacy': 'Privacy & Security',
      'dark_mode': 'Dark Mode',
      'language': 'Language',
      'device_settings': 'DEVICE SETTINGS',
      'app_settings': 'APP SETTINGS',
      'battery_alerts': 'Battery Alerts',
      'collar_management': 'Collar Management',
      'support': 'Support',
    },
    'ca': {
      'settings': 'Configuració',
      'notifications': 'Notificacions',
      'privacy': 'Privadesa i seguretat',
      'dark_mode': 'Mode fosc',
      'language': 'Idioma',
      'device_settings': 'AJUSTOS DEL DISPOSITIU',
      'app_settings': 'AJUSTOS DE L’APP',
      'battery_alerts': 'Alertes de bateria',
      'collar_management': 'Gestió del collar',
      'support': 'Suport',
    },
    'bg': {
      'settings': 'Настройки',
      'notifications': 'Известия',
      'privacy': 'Поверителност и сигурност',
      'dark_mode': 'Тъмен режим',
      'language': 'Език',
      'device_settings': 'НАСТРОЙКИ НА УСТРОЙСТВОТО',
      'app_settings': 'НАСТРОЙКИ НА ПРИЛОЖЕНИЕТО',
      'battery_alerts': 'Известия за батерията',
      'collar_management': 'Управление на нашийника',
      'support': 'Поддръжка',
    },
  };

  static String of(BuildContext context, String key) {
    final lang = Localizations.localeOf(context).languageCode;
    return _v[lang]?[key] ?? _v['en']![key] ?? key;
  }
}
